package com.in28minutes.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
//@SessionAttributes("name")
public class WelcomeController {
	
//	@Autowired
//	LoginService service;
	

	@RequestMapping(value = "/" , method = RequestMethod.GET)
	//@ResponseBody
	public String sayHello(ModelMap model) {
		
		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
		System.out.println(((UserDetails) principal).getUsername());
		
	
			
		model.put("name", ((UserDetails) principal).getUsername());
		return "welcome";
	}
	
	
//	@RequestMapping(value = "/login" , method = RequestMethod.POST)
//	//@ResponseBody
//	public String handleLoginRequest(@RequestParam String name, ModelMap model, 
//			@RequestParam String password) {
//
//     if(!service.validateUser(name, password)) {
//    	 model.put("errorMessage", "Invalid Credentials");
//    	 return "login";
//     }
//     model.addAttribute("name", name);
//	 model.addAttribute("password", password);
//	return "welcome";
//		
//	}
}