package com.in28minutes.springboot.web.service;

import org.springframework.stereotype.Component;

@Component
public class LoginServiceOLD {
	
	
	public boolean validateUser(String userid, String password) {
		
	return	userid.equalsIgnoreCase("in28minutes")
		&& password.equalsIgnoreCase("dummy");
	}

}
