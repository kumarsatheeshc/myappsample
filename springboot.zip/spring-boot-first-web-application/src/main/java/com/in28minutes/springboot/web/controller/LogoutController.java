package com.in28minutes.springboot.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
//@SessionAttributes("name")
public class LogoutController {
	
//	@Autowired
//	LoginService service;
	
	@RequestMapping(value="/logout", method = RequestMethod.GET )
//	@ResponseBody
	public String logout(HttpServletRequest request, HttpServletResponse response  ){
		//model.put("name", getLoggedInUserName(model));
		
		org.springframework.security.core.Authentication authentication = SecurityContextHolder.getContext()
				.getAuthentication();
		
		if (authentication != null) {
			new SecurityContextLogoutHandler().logout(request, response, authentication);
		}
		
		return "redirect:/";
	}
	
	private String getLoggedInUserName(ModelMap model) {
		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();

		if (principal instanceof UserDetails)
			return ((UserDetails) principal).getUsername();

		return principal.toString();
	}
	
//	@RequestMapping(value="/login", method = RequestMethod.POST )
//
//	public String showWelcomeMessage(ModelMap model, @RequestParam String name, @RequestParam String password  ){
//		boolean isValidUser = service.validateUser(name, password);
//		if (!isValidUser) {
//			model.put("errorMessage", "Invalid Credentials");
//		    return "login"; }
//		
//		model.put("name", name);
//		model.put("password", password);
//		//System.out.println("name is" + name);
//		return "welcome";
//	}
	
}