insert into TODO
values(1001,'Learn Spring Boot', false, sysdate(), 'in28Minutes');
insert into TODO
values(1002,'Learn Angular JS', false, sysdate(), 'in28Minutes');
insert into TODO
values(1003,'Learn to Dance', false, sysdate(), 'in28Minutes');