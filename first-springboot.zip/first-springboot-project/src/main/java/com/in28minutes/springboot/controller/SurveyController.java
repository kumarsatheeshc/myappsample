package com.in28minutes.springboot.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.in28minutes.springboot.model.Question;
import com.in28minutes.springboot.service.SurveyService;

@RestController
public class SurveyController {
	
	@Autowired
	private SurveyService surveyService;
	
	//GET  "/surveys/{surveyId}/questions" http://localhost:8080/surveys/Survey1/questions/
	@GetMapping("/surveys/{surveyId}/questions")	
	public List<Question> retriveQuestionsForSurvey(@PathVariable String surveyId){
		
		return surveyService.retrieveQuestions(surveyId);
		}
	
	
	//POST  "/surveys/{surveyId}/questions"
		
			//what should be structure of request body?
			//how will it be mapped to Question object?
			//what should be rerurned?
			//what should be response status?
	 @PostMapping("/surveys/{surveyId}/questions")
	    ResponseEntity<?> add(@PathVariable String surveyId,
	            @RequestBody Question question) {

	        Question createdTodo = surveyService.addQuestion(surveyId, question);

	        if (createdTodo == null) {
	            return ResponseEntity.noContent().build();
	        }

	        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
	                .path("/{id}").buildAndExpand(createdTodo.getId()).toUri();

	        return ResponseEntity.created(location).build();

	    }

	//GET  "/surveys/{surveyId}/questions/{questionId}"
	@GetMapping("/surveys/{surveyId}/questions/{questionId}")	
	public Question retriveDetailsForQuestion(@PathVariable String surveyId, @PathVariable String questionId){
		
		return surveyService.retrieveQuestion(surveyId, questionId);
		}

}
