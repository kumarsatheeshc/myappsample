package com.in28minutes.springboot;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

//spring to manage this bean and create an instance of this
@Service
public class WelcomeService{
	
	@Value("${welcome.message}")
	String welcomemessage;
	
	
	public String retirveWelcomeMessage() {
		//return "Good Morning updated 123!!";
		
		return welcomemessage;
	}
	
}