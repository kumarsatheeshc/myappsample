package com.in28minutes.springboot.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SurveyControllerIT {

	@Test
	void test() {
		//fail("Not yet implemented");
	}

}
